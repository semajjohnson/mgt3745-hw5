(() => {
  'use strict';

  const apiBase = 'https://mgt3745-hw4.semajjohnson.workers.dev';
  const maxTrackLength = 200;
  const maxSourceLength = 60;
  const maxLabelLength = 30;
  const labelsStorageKey = 'pool-mood-labels';

  const poolForm = document.querySelector('#pool-form');
  const trackInput = document.querySelector('#track-input');
  const sourceInput = document.querySelector('#source-input');
  const poolList = document.querySelector('#pool-list');
  const formError = document.querySelector('#form-error');
  const saveStatus = document.querySelector('#save-status');
  const emptyState = document.querySelector('#empty-state');
  const filterSection = document.querySelector('#filter-section');
  const filterButtons = document.querySelector('#filter-buttons');
  const activeFilterDisplay = document.querySelector('#active-filter-display');
  const activeFilterLabel = document.querySelector('#active-filter-label');
  const clearFilterButton = document.querySelector('#clear-filter');

  const api = new URLSearchParams(window.location.search).has('apiDown')
    ? apiBase + '/not-a-real-endpoint'
    : apiBase + '/entries';

  let poolItems = [];
  let moodLabels = {};
  let activeFilter = null;

  function showError(message) {
    formError.textContent = message;
    saveStatus.textContent = '';
  }

  // Labels persist in localStorage because the Cloudflare Worker does not
  // store them; they are a client-side organizational layer on top of the pool.
  function loadMoodLabels() {
    try {
      const stored = localStorage.getItem(labelsStorageKey);
      return stored ? JSON.parse(stored) : {};
    } catch {
      return {};
    }
  }

  function saveMoodLabels() {
    try {
      localStorage.setItem(labelsStorageKey, JSON.stringify(moodLabels));
    } catch {
      // localStorage may be unavailable (private mode); labels just won't persist.
    }
  }

  function getTrackKey(item) {
    return item.track.toLowerCase();
  }

  // Only labels the user has actually placed on an item are offered as filters,
  // never suggested or pre-populated (A13).
  function getAvailableLabels() {
    const labels = new Set();
    Object.values(moodLabels).forEach(itemLabels => {
      itemLabels.forEach(label => labels.add(label));
    });
    return Array.from(labels).sort();
  }

  // The server returns one row per track-and-person pair, so a track
  // recommended by two people is merged here for display (A6).
  function mergeByTrack(rows) {
    const merged = [];
    rows.forEach(row => {
      const match = merged.find(item => item.track.toLowerCase() === row.track.toLowerCase());
      if (match) {
        match.sources.push(row.source);
        match.ids.push(row.id);
      } else {
        merged.push({ track: row.track, sources: [row.source], ids: [row.id], createdAt: row.created_at });
      }
    });
    return merged;
  }

  async function loadPool() {
    try {
      const response = await fetch(api);
      if (!response.ok) {
        showError('Could not load the pool. The server returned ' + response.status + '.');
        return [];
      }
      return mergeByTrack(await response.json());
    } catch {
      // A network failure must say so on the page rather than only in the console.
      showError('Could not reach the server. Check your connection and reload.');
      return [];
    }
  }

  async function savePool(track, source) {
    try {
      const response = await fetch(api, {
        method: 'POST',
        headers: { 'content-type': 'application/json' },
        body: JSON.stringify({ track, source })
      });
      if (response.ok) return true;
      // The Worker's 400 messages name the problem, so they are shown as written.
      showError(await response.text());
      return false;
    } catch {
      showError('Could not reach the server. Your entry was not saved.');
      return false;
    }
  }

  async function dismissItem(id) {
    try {
      const response = await fetch(apiBase + '/entries/' + id + '/dismiss', { method: 'POST' });
      if (!response.ok) {
        showError('Could not dismiss that item. The server returned ' + response.status + '.');
        return;
      }
      poolItems = await loadPool();
      renderPool();
      renderFilters();
      saveStatus.textContent = 'Dismissed. It will not come back from that person.';
    } catch {
      showError('Could not reach the server. Nothing was dismissed.');
    }
  }

  function formatSources(sources) {
    if (sources.length === 1) return sources[0];
    return `${sources.slice(0, -1).join(', ')} and ${sources[sources.length - 1]}`;
  }

  function formatDate(text) {
    const parsed = new Date(text.replace(' ', 'T') + 'Z');
    return Number.isNaN(parsed.getTime())
      ? text
      : parsed.toLocaleDateString(undefined, { year: 'numeric', month: 'short', day: 'numeric' });
  }

  function addLabel(trackKey, label) {
    const trimmed = label.trim();
    if (trimmed.length < 1) {
      showError('Enter a mood label of 1 to ' + maxLabelLength + ' characters.');
      return false;
    }
    if (trimmed.length > maxLabelLength) {
      showError('Mood labels must be ' + maxLabelLength + ' characters or fewer. "' + trimmed + '" is too long.');
      return false;
    }
    if (!moodLabels[trackKey]) {
      moodLabels[trackKey] = [];
    }
    if (moodLabels[trackKey].some(existing => existing.toLowerCase() === trimmed.toLowerCase())) {
      showError('That item already has the label "' + trimmed + '".');
      return false;
    }
    moodLabels[trackKey].push(trimmed);
    saveMoodLabels();
    return true;
  }

  function removeLabel(trackKey, label) {
    if (!moodLabels[trackKey]) return;
    moodLabels[trackKey] = moodLabels[trackKey].filter(existing => existing !== label);
    if (moodLabels[trackKey].length === 0) {
      delete moodLabels[trackKey];
    }
    saveMoodLabels();
  }

  function applyFilter(label) {
    activeFilter = label;
    renderPool();
    renderFilters();
  }

  function clearFilter() {
    activeFilter = null;
    renderPool();
    renderFilters();
  }

  function renderFilters() {
    filterButtons.replaceChildren();
    const available = getAvailableLabels();

    // If the active filter label no longer exists on any item, drop it silently.
    if (activeFilter && !available.some(label => label.toLowerCase() === activeFilter.toLowerCase())) {
      activeFilter = null;
    }

    if (available.length === 0) {
      filterSection.hidden = true;
      activeFilterDisplay.hidden = true;
      return;
    }

    filterSection.hidden = false;

    available.forEach(label => {
      const button = document.createElement('button');
      button.type = 'button';
      button.className = 'filter-button';
      button.textContent = label;
      button.setAttribute('aria-pressed', activeFilter === label ? 'true' : 'false');
      if (activeFilter === label) {
        button.classList.add('filter-button-active');
      }
      button.addEventListener('click', () => {
        if (activeFilter === label) {
          clearFilter();
        } else {
          applyFilter(label);
        }
      });
      filterButtons.append(button);
    });

    // While a filter is active, show which label is filtering and offer a clear (A14).
    if (activeFilter) {
      activeFilterDisplay.hidden = false;
      activeFilterLabel.textContent = activeFilter;
    } else {
      activeFilterDisplay.hidden = true;
    }
  }

  function renderLabelsForItem(item, trackKey) {
    const labelContainer = document.createElement('div');
    labelContainer.className = 'label-container';

    const labels = moodLabels[trackKey] || [];
    labels.forEach(label => {
      const tag = document.createElement('span');
      tag.className = 'label-tag';

      const tagText = document.createElement('span');
      tagText.className = 'label-tag-text';
      tagText.textContent = label;

      const removeBtn = document.createElement('button');
      removeBtn.type = 'button';
      removeBtn.className = 'label-tag-remove';
      removeBtn.textContent = '×';
      removeBtn.setAttribute('aria-label', 'Remove label ' + label + ' from ' + item.track);
      removeBtn.addEventListener('click', () => {
        removeLabel(trackKey, label);
        renderPool();
        renderFilters();
        saveStatus.textContent = 'Removed label "' + label + '".';
      });

      tag.append(tagText, removeBtn);
      labelContainer.append(tag);
    });

    // Plain text input with no datalist or suggestions — the user creates
    // their own labels and the system never pre-populates them (A13).
    const labelForm = document.createElement('form');
    labelForm.className = 'label-form';

    const labelInput = document.createElement('input');
    labelInput.type = 'text';
    labelInput.name = 'mood-label';
    labelInput.className = 'label-input';
    labelInput.placeholder = 'Add mood label';
    labelInput.maxLength = maxLabelLength;
    labelInput.setAttribute('aria-label', 'Mood label for ' + item.track);
    labelInput.setAttribute('aria-describedby', 'form-error');

    const labelButton = document.createElement('button');
    labelButton.type = 'submit';
    labelButton.className = 'label-add-button';
    labelButton.textContent = 'Add';

    labelForm.append(labelInput, labelButton);

    labelForm.addEventListener('submit', event => {
      event.preventDefault();
      formError.textContent = '';
      if (addLabel(trackKey, labelInput.value)) {
        labelInput.value = '';
        renderPool();
        renderFilters();
        saveStatus.textContent = 'Label added to "' + item.track + '".';
      }
    });

    labelContainer.append(labelForm);
    return labelContainer;
  }

  function renderPool() {
    poolList.replaceChildren();

    // When a filter is active, only items carrying that label are shown (A11).
    const items = activeFilter
      ? poolItems.filter(item => {
          const labels = moodLabels[getTrackKey(item)] || [];
          return labels.some(label => label.toLowerCase() === activeFilter.toLowerCase());
        })
      : poolItems;

    emptyState.hidden = items.length > 0;
    if (items.length === 0 && activeFilter) {
      emptyState.hidden = false;
      emptyState.textContent = 'No items with the label "' + activeFilter + '".';
    } else {
      emptyState.textContent = 'Nothing in the pool yet.';
    }

    items.forEach(item => {
      const trackKey = getTrackKey(item);
      const listItem = document.createElement('li');
      const details = document.createElement('div');
      details.className = 'item-details';

      const trackText = document.createElement('span');
      trackText.className = 'item-track';
      trackText.textContent = item.track;

      const metaText = document.createElement('span');
      metaText.className = 'item-meta';
      metaText.textContent = `from ${formatSources(item.sources)} · added ${formatDate(item.createdAt)}`;

      details.append(trackText, metaText);

      // Labels are stored and displayed on the item they belong to (A10).
      const labelContainer = renderLabelsForItem(item, trackKey);
      details.append(labelContainer);

      const dismissButton = document.createElement('button');
      dismissButton.type = 'button';
      dismissButton.className = 'remove-button';
      dismissButton.textContent = 'Dismiss';
      dismissButton.setAttribute('aria-label', `Dismiss ${item.track}`);
      dismissButton.addEventListener('click', () => {
        item.ids.forEach(id => dismissItem(id));
      });

      listItem.append(details, dismissButton);
      poolList.append(listItem);
    });
  }

  function showFieldError(message, field) {
    field.setAttribute('aria-invalid', 'true');
    showError(message);
    field.focus();
  }

  poolForm.addEventListener('submit', async event => {
    event.preventDefault();
    trackInput.removeAttribute('aria-invalid');
    sourceInput.removeAttribute('aria-invalid');
    formError.textContent = '';

    const track = trackInput.value.trim();
    const source = sourceInput.value.trim();

    if (track.length < 1 || track.length > maxTrackLength) {
      showFieldError(`Enter a track of 1 to ${maxTrackLength} characters.`, trackInput);
      return;
    }
    if (source.length < 1 || source.length > maxSourceLength) {
      showFieldError(`Enter the name of the person this came from, 1 to ${maxSourceLength} characters.`, sourceInput);
      return;
    }

    if (!await savePool(track, source)) return;

    poolItems = await loadPool();
    renderPool();
    renderFilters();
    trackInput.value = '';
    sourceInput.value = '';
    trackInput.focus();
    saveStatus.textContent = `Added to the pool from ${source}.`;
  });

  clearFilterButton.addEventListener('click', clearFilter);

  moodLabels = loadMoodLabels();
  loadPool().then(items => {
    poolItems = items;
    renderPool();
    renderFilters();
  });
})();
